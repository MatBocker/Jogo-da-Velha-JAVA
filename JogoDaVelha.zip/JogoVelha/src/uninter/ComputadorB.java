package uninter;

import java.util.Random;

public class ComputadorB extends Computador {
	// Dificuldade 2, Todas as jogadas desse computador seguem a ordem, jogando somente nos espaços vazios
	
	int linha = 0;
	int coluna = 0;

	public ComputadorB() {

	}
    // Método responsavel pela jogada do ComputadorB
	public void jogar(Tabuleiro tab) {
		loop(tab);
		tab.mat[linha][coluna] = -1;
	}
    // Método para verificar se a próxima posição é um espaço vazio
	public void loop(Tabuleiro tab) {

		for (int i = 0; i < tab.mat.length; i++) { // linhas
			for (int j = 0; j < tab.mat.length; j++) { // colunas
				if (tab.mat[i][j] == 0) {
					linha = i;
					coluna = j;
					return;
				}
			}
		}

	}

}
