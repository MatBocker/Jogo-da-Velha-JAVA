package uninter;

import java.util.Random;

public class ComputadorA extends Computador {
	// Dificuldade 1, todas as jogadas do computador são randomizadas
	
	public ComputadorA() {

	}
	// Método responsavel pela jogada do ComputadorA
	public void jogar(Tabuleiro tab) {
		Random rand = new Random();
		int valor = 3;
		// gera valores aleatórios de 0 a 2
		int linha = rand.nextInt(valor);
		int coluna = rand.nextInt(valor);
		// testa se a posição gerada não está preenchida
		while (tab.tentativa(linha, coluna) == false) {
			linha = rand.nextInt(valor);
			coluna = rand.nextInt(valor);
		}
		tab.mat[linha][coluna] = -1;
	}
}
