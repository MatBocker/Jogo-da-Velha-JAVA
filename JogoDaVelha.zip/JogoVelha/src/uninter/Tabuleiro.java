package uninter;

public class Tabuleiro {
	public int mat[][] = new int[3][3];
	// 1 - X - Jogador
	// -1 - O - Computador
	// 0 - Espaço vazio

	public Tabuleiro() {
	}
    // zera todas as posições da matriz
	public void zerarPosicoes() {
		for (int i = 0; i < mat.length; i++) { // linhas
			for (int j = 0; j < mat.length; j++) { // colunas
				mat[i][j] = 0;
			}
		}

	}
    //método para verificar se todas as opções do jogo foram preenchidas
	public boolean verificarJogoPosicoes() {
		int slots = 9;
		int cont = 0;

		for (int i = 0; i < mat.length; i++) { // linhas
			for (int j = 0; j < mat.length; j++) { // colunas
				if (mat[i][j] != 0) {
					cont += 1;
				}
			}

		}
		if (cont == slots) {
			return true;
		} else {
			return false;
		}

	}
     // método para verificar se alguem venceu o jogo ou terminou em empate
	public int situacao() {
		int fim = 0;
			// Jogador verifica vitoria
			if (mat[0][0] == 1 && mat[0][1] == 1 && mat[0][2] == 1) {
				fim = 1;
			} 
			else if (mat[1][0] == 1 && mat[1][1] == 1 && mat[1][2] == 1) {
				fim = 1;
			}

			else if (mat[2][0] == 1 && mat[2][1] == 1 && mat[2][2] == 1) {
				fim = 1;
			}

			else if (mat[0][0] == 1 && mat[1][0] == 1 && mat[2][0] == 1) {
				fim = 1;
			} 
			else if (mat[0][1] == 1 && mat[1][1] == 1 && mat[2][1] == 1) {
				fim = 1;
			} 
			else if (mat[0][2] == 1 && mat[1][2] == 1 && mat[2][2] == 1) {
				fim = 1;
			} 
			else if (mat[0][0] == 1 && mat[1][1] == 1 && mat[2][2] == 1) {
				fim = 1;
			} 
			else if (mat[0][2] == 1 && mat[1][1] == 1 && mat[2][0] == 1) {
				fim = 1;
			}

			// Computador verifica vitória

			else if (mat[0][0] == -1 && mat[0][1] == -1 && mat[0][2] == -1) {
				fim = 2;
			} 
			else if (mat[1][0] == -1 && mat[1][1] == -1 && mat[1][2] == -1) {
				fim = 2;
			}
			else if (mat[2][0] == -1 && mat[2][1] == -1 && mat[2][2] == -1) {
				fim = 2;
			}
			else if (mat[0][0] == -1 && mat[1][0] == -1 && mat[2][0] == -1) {
				fim = 2;
			} 
			else if (mat[0][1] == -1 && mat[1][1] == -1 && mat[2][1] == -1) {
				fim = 2;
			} 
			else if (mat[0][2] == -1 && mat[1][2] == -1 && mat[2][2] == -1) {
				fim = 2;
			} 
			else if (mat[0][0] == -1 && mat[1][1] == -1 && mat[2][2] == -1) {
				fim = 2;
			} 
			else if (mat[0][2] == -1 && mat[1][1] == -1 && mat[2][0] == -1) {
				fim = 2;
			}
			else if(verificarJogoPosicoes() == true ) {
				fim = 3;
			}

		return fim;

	}
    // Método para imprimir o jogo da velha no console
	public void visualizar() {
		for (int i = 0; i < mat.length; i++) { // linhas
			for (int j = 0; j < mat.length; j++) { // colunas
				if (mat[i][j] == 1) {
					System.out.print("X");
				} else if (mat[i][j] == -1) {
					System.out.print("O");
				} else {
					System.out.print("-");
				}

				if (j == 0 || j == 1)
					System.out.print(" | ");
			}
			System.out.println();

		}
	}

	// Método que verifica se a jogada foi em uma posição vazia
	public boolean tentativa(int linha, int coluna) {
		if (mat[linha][coluna] != 0) {
			return false;
		} else {
			return true;
		}
	}

}
