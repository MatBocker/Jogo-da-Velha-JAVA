package uninter;

import java.util.Scanner;

public class Jogador {

	public Jogador() {
	}
    // Método responsavel pela jogada do Jogador
	public void jogar(Tabuleiro tab) {
		int linha = 0;
		int coluna = 0;
		Scanner teclado = new Scanner(System.in);
		System.out.println("----------------------------");
		System.out.println("Agora eh a sua vez de jogar!");
		System.out.println("----------------------------");
		//testa se a linha digita está no tamanho da matriz
		do
		{
			System.out.println("Digite a linha:");
			linha = teclado.nextInt();
			
		}while(linha > 2 || linha < 0);
		//testa se a coluna digita está no tamanho da matriz
		do
		{
			System.out.println("Digite a coluna:");
			coluna = teclado.nextInt();
			
		}while(coluna > 2 || coluna < 0);
			
		// Testa se o lugar escolhido está vazio
		while (tab.tentativa(linha, coluna) == false) {
			System.out.println("----------------------------");
			System.out.println("Lugar já está preenchido, tente outro!");
			System.out.println("----------------------------");
			//testa se a linha digita está no tamanho da matriz
			do
			{
				System.out.println("Digite a linha:");
				linha = teclado.nextInt();
				
			}while(linha > 2 || linha < 0);
			//testa se a coluna digita está no tamanho da matriz
			do
			{
				System.out.println("Digite a coluna:");
				coluna = teclado.nextInt();
				
			}while(coluna > 2 || coluna < 0);
		}
		tab.mat[linha][coluna] = 1;
	}
}
