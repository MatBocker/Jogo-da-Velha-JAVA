package uninter;

import java.util.Random;

public class ComputadorC extends Computador {
	// Dificuldade 3, Nessa dificuldade o computador começa jogando e preenche a opção do centro na primeira jogada, após isso ele randomiza as jogadas restantes
	int rodada = 0;

	public ComputadorC() {

	}
	// Método responsavel pela jogada do ComputadorC
	public void jogar(Tabuleiro tab) {
        // Faz a primeira jogada no centro
		if (rodada == 0) {
			tab.mat[1][1] = -1;
			rodada += 1;
		} else {
			Random rand = new Random();
			int valor = 3;
			// gera valores aleatórios de 0 a 2
			int linha = rand.nextInt(valor);
			int coluna = rand.nextInt(valor);
			while (tab.tentativa(linha, coluna) == false) {
				linha = rand.nextInt(valor);
				coluna = rand.nextInt(valor);
			}
			tab.mat[linha][coluna] = -1;
		}

	}
}
