package uninter;

public class Computador {
	
	//Classe computador
	public Computador() {

	}

	public void jogar(Tabuleiro tab) {
	}
}
