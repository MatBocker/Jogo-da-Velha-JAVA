package uninter;

import java.util.Scanner;

public class Jogo {

	public static void main(String[] args) {
		Tabuleiro tab = new Tabuleiro();
		Jogador jog = new Jogador();
		Computador comp;
		int opcao = 0;

		Scanner teclado = new Scanner(System.in);
		System.out.println("Jogo da Velha");
        //while para escolher a dificuldade do jogo
		while (true) {
			System.out.println("Escolha a dificuldade 1,2,3:");
			opcao = teclado.nextInt();

			if (opcao == 1) {
				comp = new ComputadorA();
				break;
			} else if (opcao == 2) {
				comp = new ComputadorB();
				break;
			}

			else if (opcao == 3) {
				comp = new ComputadorC();
				break;
			}

			else {
				System.out.println("Essa dificuldade não existe!");
				continue;
			}

		}
		int vez = 1;
		tab.zerarPosicoes();
		tab.visualizar();
		System.out.println("---------------------");
		// while para verificar a situacao do jogo, continua no while até alguem vencer ou o jogo empatar
		while (tab.situacao() == 0) {
			// se a dificuldade escolhida for 1 e 2 o jogador começa jogando
			if (opcao == 1 || opcao == 2) {
				if (vez == 1) // Jogador
				{
					jog.jogar(tab);

					vez = 2;
				} else if (vez == 2) // Computador
				{
					comp.jogar(tab);
					vez = 1;
				}
			}
			// se a dificuldade escolhida for 3 o computador começa jogando
			else if (opcao == 3) {
				if (vez == 1) // Computador
				{
					comp.jogar(tab);

					vez = 2;
				} else if (vez == 2) // Jogador
				{
					jog.jogar(tab);
					vez = 1;
				}
			}

			System.out.println("---------------------");
			tab.visualizar();
		}

		//teste para imprimir mensagem de vencedor ou empate
		if (tab.situacao() == 1) {
			System.out.println("Jogador Venceu!");
		} else if (tab.situacao() == 2) {
			System.out.println("Computador Venceu!");
		} else if (tab.situacao() == 3) {
			System.out.println("Jogo Empatou!");
		}

		System.out.println("---------------------");
		tab.visualizar();

	}

}
